import './style.css';

/* ---------------- data ---------------- */
const PAL = {
  ash:'#c9c4d6', ink:'#8f8aa0', ox:'#a2313f', oxl:'#c9424f', candle:'#c9a15c', pale:'#8ea0ad'
};
const books = [
  {t:'El Jardín de las Cenizas', a:'V. Solano', kind:'novela', pages:412, prog:.34, code:'OK-014·Σ', sym:'tree',  grad:['#1a1420','#08070b'], ink:'#b98a94', recent:2, added:8},
  {t:'Hemogótico', a:'R. Ámber', kind:'manga', pages:196, prog:.72, code:'OK-207·M', sym:'eye',   grad:['#241016','#0a0608'], ink:'#c9424f', recent:0, added:3},
  {t:'La Casa que Respira', a:'M. del Valle', kind:'novela', pages:288, prog:0, code:'OK-031·Σ', sym:'door', grad:['#141a1c','#070a0b'], ink:'#8ea0ad', recent:14, added:1},
  {t:'Nocturno de los Ahogados', a:'E. Prieto', kind:'novela', pages:344, prog:.11, code:'OK-058·Σ', sym:'wave', grad:['#101820','#06080b'], ink:'#7f97ab', recent:5, added:11},
  {t:'Marrow', a:'J. Krohn', kind:'manga', pages:220, prog:.5, code:'OK-119·M', sym:'ribs', grad:['#1e1620','#08070a'], ink:'#c7b5c0', recent:1, added:6},
  {t:'Tratado de Sombras', a:'Anónimo', kind:'ensayo', pages:167, prog:.9, code:'OK-002·Λ', sym:'sigil', grad:['#1a1712','#080706'], ink:'#c9a15c', recent:9, added:20},
  {t:'Umbral', a:'C. Vega', kind:'manga', pages:180, prog:0, code:'OK-221·M', sym:'moth', grad:['#181422','#07060a'], ink:'#a88fc4', recent:30, added:2},
  {t:'La Procesión Muda', a:'F. Ossorio', kind:'novela', pages:390, prog:.22, code:'OK-076·Σ', sym:'candle', grad:['#201811','#090705'], ink:'#c9a15c', recent:4, added:15},
  {t:'Cuerpos de Agua Negra', a:'I. Rendón', kind:'poesía', pages:96, prog:.63, code:'OK-045·Π', sym:'moon', grad:['#12161f','#06070a'], ink:'#93a6b6', recent:7, added:9},
  {t:'El Coro Hueco', a:'D. Salazar', kind:'manga', pages:240, prog:.05, code:'OK-233·M', sym:'key', grad:['#22131a','#090608'], ink:'#c47c86', recent:12, added:4},
  {t:'Reliquias del Insomnio', a:'A. Bran', kind:'ensayo', pages:210, prog:.41, code:'OK-011·Λ', sym:'hourglass', grad:['#1b1622','#08070b'], ink:'#b6a2c9', recent:6, added:18},
  {t:'Los Que Miran Debajo', a:'S. Cordero', kind:'novela', pages:466, prog:.16, code:'OK-089·Σ', sym:'spiral', grad:['#141220','#07060b'], ink:'#9c93bf', recent:3, added:7},
];
books.forEach((b,i)=>b.id=i);

/* ---------------- procedural cover art ---------------- */
function symbolMarkup(name, ink){
  const s = {
    tree:`<g stroke="${ink}" fill="none" stroke-width="1.4" opacity=".55"><path d="M150 250V150"/><path d="M150 168c-14-16-30-16-42-30M150 168c14-16 30-16 42-30M150 138c-10-14-24-12-32-26M150 138c10-14 24-12 32-26M150 118c-7-11-16-10-22-22M150 118c7-11 16-10 22-22"/></g><circle cx="150" cy="86" r="30" fill="none" stroke="${ink}" stroke-width="1" opacity=".3"/>`,
    eye:`<g fill="none" stroke="${ink}" stroke-width="1.5" opacity=".6"><path d="M100 165q50-46 100 0q-50 46-100 0z"/><circle cx="150" cy="165" r="20"/></g><circle cx="150" cy="165" r="7" fill="${ink}" opacity=".85"/><g stroke="${ink}" stroke-width="1" opacity=".25"><path d="M150 118v-22M150 234v-22M92 165H70M230 165h-22"/></g>`,
    door:`<g fill="none" stroke="${ink}" stroke-width="1.4" opacity=".55"><rect x="110" y="96" width="80" height="150" rx="40"/><rect x="122" y="112" width="56" height="134" rx="28"/></g><circle cx="168" cy="176" r="3.2" fill="${ink}"/><rect x="126" y="248" width="48" height="1.5" fill="${ink}" opacity=".3"/>`,
    wave:`<g fill="none" stroke="${ink}" stroke-width="1.4" opacity=".5"><path d="M70 150q20-16 40 0t40 0 40 0 40 0"/><path d="M70 172q20-16 40 0t40 0 40 0 40 0"/><path d="M70 194q20-16 40 0t40 0 40 0 40 0"/><path d="M70 128q20-16 40 0t40 0 40 0 40 0"/></g>`,
    ribs:`<g fill="none" stroke="${ink}" stroke-width="1.4" opacity=".55"><path d="M150 96v150"/><path d="M150 120q-34 6-40 30M150 120q34 6 40 30M150 148q-32 6-36 28M150 148q32 6 36 28M150 176q-28 6-30 26M150 176q28 6 30 26"/></g>`,
    sigil:`<g fill="none" stroke="${ink}" stroke-width="1.2" opacity=".55"><circle cx="150" cy="165" r="52"/><path d="M150 118l45 70h-90z"/><path d="M150 150v40M132 178h36"/></g><circle cx="150" cy="165" r="66" fill="none" stroke="${ink}" stroke-width=".7" opacity=".25"/>`,
    moth:`<g fill="none" stroke="${ink}" stroke-width="1.3" opacity=".55"><path d="M150 150c-30-34-64-24-64 6s34 40 64 26M150 150c30-34 64-24 64 6s-34 40-64 26M150 138v56"/></g><circle cx="118" cy="158" r="4" fill="${ink}" opacity=".5"/><circle cx="182" cy="158" r="4" fill="${ink}" opacity=".5"/>`,
    candle:`<g fill="none" stroke="${ink}" stroke-width="1.4" opacity=".6"><rect x="138" y="150" width="24" height="86"/><path d="M150 150v-18"/></g><path d="M150 108c0 12-9 14-9 24a9 9 0 0 0 18 0c0-8-9-12-9-24z" fill="${ink}" opacity=".55"/>`,
    moon:`<path d="M172 110a56 56 0 1 0 0 110 46 46 0 1 1 0-110z" fill="${ink}" opacity=".5"/><circle cx="150" cy="165" r="64" fill="none" stroke="${ink}" stroke-width=".7" opacity=".25"/>`,
    key:`<g fill="none" stroke="${ink}" stroke-width="1.5" opacity=".6"><circle cx="150" cy="120" r="22"/><path d="M150 142v88M150 200h16M150 214h12"/></g><circle cx="150" cy="120" r="7" fill="none" stroke="${ink}" stroke-width="1.5" opacity=".6"/>`,
    hourglass:`<g fill="none" stroke="${ink}" stroke-width="1.4" opacity=".6"><path d="M118 108h64M118 224h64M122 108c0 34 28 40 28 58 0-18 28-24 28-58M122 224c0-34 28-40 28-58 0 18 28 24 28 58"/></g><path d="M150 166c-8 8-14 22-14 40h28c0-18-6-32-14-40z" fill="${ink}" opacity=".4"/>`,
    spiral:`<path d="M150 165m0 0a8 8 0 1 1 8 8 18 18 0 1 1-18-18 30 30 0 1 1 30 30 44 44 0 1 1-44-44" fill="none" stroke="${ink}" stroke-width="1.4" opacity=".55"/>`
  };
  return s[name]||s.sigil;
}
function coverSVG(b){
  const id=b.id;
  return `<svg viewBox="0 0 300 400" preserveAspectRatio="xMidYMid slice">
    <defs>
      <linearGradient id="cg${id}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stop-color="${b.grad[0]}"/><stop offset="1" stop-color="${b.grad[1]}"/>
      </linearGradient>
      <radialGradient id="cv${id}" cx="0.5" cy="0.42" r="0.75">
        <stop offset="0.5" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity="0.72"/>
      </radialGradient>
      <filter id="cn${id}"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" stitchTiles="stitch"/><feColorMatrix type="saturate" values="0"/><feComponentTransfer><feFuncA type="linear" slope="0.05"/></feComponentTransfer><feComposite operator="in" in2="SourceGraphic"/></filter>
    </defs>
    <rect width="300" height="400" fill="url(#cg${id})"/>
    <g transform="translate(0,20)">${symbolMarkup(b.sym,b.ink)}</g>
    <rect width="300" height="400" fill="url(#cv${id})"/>
    <rect width="300" height="400" fill="#fff" filter="url(#cn${id})"/>
  </svg>`;
}

/* ---------------- library render ---------------- */
const shelf=document.getElementById('shelf');
const kindLabel={manga:'Manga',novela:'Novela',ensayo:'Ensayo',poesía:'Poesía'};
let view='grid', sortKey='recent', query='';

function statusText(b){
  if(b.prog===0) return 'Sin empezar';
  if(b.prog>=1) return 'Terminado';
  return 'Página '+Math.round(b.prog*b.pages)+' · '+Math.round(b.prog*100)+'%';
}
function sortBooks(list){
  const c=[...list];
  if(sortKey==='recent') c.sort((a,b)=>a.recent-b.recent);
  else if(sortKey==='added') c.sort((a,b)=>a.added-b.added);
  else if(sortKey==='title') c.sort((a,b)=>a.t.localeCompare(b.t));
  else if(sortKey==='author') c.sort((a,b)=>a.a.localeCompare(b.a));
  else if(sortKey==='progress') c.sort((a,b)=>b.prog-a.prog);
  return c;
}
function render(){
  const q=query.trim().toLowerCase();
  let list=books.filter(b=>!q||b.t.toLowerCase().includes(q)||b.a.toLowerCase().includes(q));
  list=sortBooks(list);
  shelf.className='shelf'+(view==='list'?' list':'');
  if(!list.length){shelf.innerHTML='<p class="empty">Nada en las sombras con ese nombre.</p>';return;}
  shelf.innerHTML=list.map((b,i)=>{
    const isManga=b.kind==='manga';
    const delay=Math.min(i*55,560);
    return `<article class="book" data-id="${b.id}" style="animation-delay:${delay}ms">
      <div class="cover">
        <span class="glow"></span>
        ${coverSVG(b)}
        <span class="spine"></span>
        <span class="kindtag ${isManga?'manga':''}">${kindLabel[b.kind]||b.kind}</span>
        <div class="titleplate grid-hideinlist">
          <h3>${b.t}</h3>
          <div class="by">${b.a}</div>
        </div>
      </div>
      <div class="lt list-only">
        <h3>${b.t}</h3><div class="by">${b.a}</div>
      </div>
      <div class="meta">
        <div class="line1"><span class="code">${b.code}</span><span class="pages">${b.pages} p.</span></div>
        <div class="progress"><i style="width:${Math.round(b.prog*100)}%"></i></div>
        <div class="status list-only-hide">${statusText(b)}</div>
      </div>
    </article>`;
  }).join('');
}
document.getElementById('search').addEventListener('input',e=>{query=e.target.value;render();});
document.getElementById('sort').addEventListener('change',e=>{sortKey=e.target.value;render();});
document.getElementById('viewtoggle').addEventListener('click',e=>{
  const btn=e.target.closest('button');if(!btn)return;
  view=btn.dataset.view;
  [...e.currentTarget.children].forEach(c=>c.classList.toggle('on',c===btn));
  render();
});
shelf.addEventListener('click',e=>{
  const card=e.target.closest('.book');if(!card)return;
  openReader(+card.dataset.id);
});
document.getElementById('navcount').textContent=books.length;
document.getElementById('volcount').textContent=books.length;

/* ---------------- reader page art ---------------- */
function pageSVG(n,total,ink){
  // pick a panel template deterministically
  const tpl=n%4;
  const layouts=[
    [[24,60,252,150],[24,222,120,150],[156,222,120,150]],
    [[24,60,252,110],[24,182,252,90],[24,284,252,88]],
    [[24,60,120,312],[156,60,120,150],[156,222,120,150]],
    [[24,60,252,312]]
  ];
  const panels=layouts[tpl];
  let inner='';
  panels.forEach((p,i)=>{
    const [x,y,w,h]=p, cx=x+w/2, cy=y+h/2;
    inner+=`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="#0c0a10" stroke="#2a2431" stroke-width="1"/>`;
    // faint scene art
    inner+=`<g clip-path="inset(0)" opacity=".8"><rect x="${x}" y="${y}" width="${w}" height="${h}" fill="url(#pg${n})"/></g>`;
    if((i+n)%3===0){ // a figure silhouette
      inner+=`<path d="M${cx} ${y+h-14} q-2 -${h*0.34} 3 -${h*0.42} q1 -14 -6 -20 q6 -3 12 0 q-7 6 -6 20 q5 .08 3 ${h*0.42}z" fill="#05040688" stroke="${ink}" stroke-width=".7" opacity=".5"/>`;
    } else if((i+n)%3===1){ // speed lines
      let sl='';for(let k=0;k<7;k++){const yy=y+10+k*(h-20)/6;sl+=`<path d="M${x+8} ${yy} L${x+w-8} ${cy}" stroke="${ink}" stroke-width=".6" opacity=".3"/>`;}
      inner+=sl;
    } else { // a distant moon / horizon
      inner+=`<circle cx="${x+w*0.7}" cy="${y+h*0.32}" r="${Math.min(w,h)*0.16}" fill="none" stroke="${ink}" stroke-width="1" opacity=".45"/><path d="M${x} ${y+h*0.66} q${w*0.5} -18 ${w} 0" stroke="${ink}" stroke-width=".8" opacity=".35" fill="none"/>`;
    }
    // occasional speech balloon
    if(i===0 && n%2===0){
      inner+=`<ellipse cx="${x+w*0.32}" cy="${y+h*0.26}" rx="${w*0.2}" ry="${h*0.1}" fill="#efeaf2" opacity=".9"/><path d="M${x+w*0.24} ${y+h*0.34} l-8 12 l16 -8z" fill="#efeaf2" opacity=".9"/>`;
      inner+=`<line x1="${x+w*0.18}" y1="${y+h*0.22}" x2="${x+w*0.46}" y2="${y+h*0.22}" stroke="#2a2431" stroke-width="1.4"/><line x1="${x+w*0.2}" y1="${y+h*0.28}" x2="${x+w*0.42}" y2="${y+h*0.28}" stroke="#2a2431" stroke-width="1.4"/>`;
    }
  });
  return `<svg viewBox="0 0 300 400" preserveAspectRatio="xMidYMid slice">
    <defs>
      <radialGradient id="pg${n}" cx="0.5" cy="0.35" r="0.9"><stop offset="0" stop-color="#1a1622"/><stop offset="1" stop-color="#08070b"/></radialGradient>
    </defs>
    <rect width="300" height="400" fill="#08070b"/>
    ${inner}
    <text x="278" y="388" text-anchor="end" font-family="'JetBrains Mono',monospace" font-size="9" fill="#4a4557">${String(n).padStart(2,'0')} / ${String(total).padStart(2,'0')}</text>
  </svg>`;
}

/* ---------------- reader logic ---------------- */
const reader=document.getElementById('reader');
const viewport=document.getElementById('viewport');
const track=document.getElementById('track');
let R={book:null,page:1,total:1,mode:'horizontal'};

function buildTicks(total){
  const t=document.getElementById('ticks');
  t.innerHTML=Array.from({length:Math.min(total,40)},()=>'<span></span>').join('');
}
function renderPages(){
  const b=R.book;
  if(R.mode==='horizontal'){
    track.classList.remove('vertical');
    viewport.classList.remove('vertical');
    track.innerHTML=`<div class="page reveal" id="curpage"><div class="art">${pageSVG(R.page,R.total,b.ink)}</div><div class="veil"></div></div>`;
  } else {
    track.classList.add('vertical');
    viewport.classList.add('vertical');
    let html='';
    for(let p=1;p<=R.total;p++){
      html+=`<div class="page" data-p="${p}"><div class="art">${pageSVG(p,R.total,b.ink)}</div><div class="veil" style="display:none"></div></div>`;
    }
    track.innerHTML=html;
    // reveal on scroll
    requestAnimationFrame(()=>observeVertical());
  }
  updateChrome();
}
let io=null;
function observeVertical(){
  if(io)io.disconnect();
  io=new IntersectionObserver((entries)=>{
    entries.forEach(en=>{
      if(en.isIntersecting){
        const pg=en.target;
        if(!pg.dataset.shown){
          pg.dataset.shown='1';
          pg.querySelector('.veil').style.display='block';
          pg.classList.add('reveal');
        }
        R.page=+pg.dataset.p; updateChrome(false);
      }
    });
  },{root:viewport,threshold:.35});
  track.querySelectorAll('.page').forEach(p=>io.observe(p));
}
function updateChrome(){
  document.getElementById('rcount').textContent=String(R.page).padStart(2,'0')+' / '+String(R.total).padStart(2,'0');
  document.getElementById('scnum').textContent=R.page;
  document.getElementById('sctotal').textContent=R.total;
  const pct=R.total>1?((R.page-1)/(R.total-1))*100:0;
  document.getElementById('scfill').style.width=pct+'%';
  document.getElementById('scknob').style.left=pct+'%';
}
function goPage(n){
  n=Math.max(1,Math.min(R.total,n));
  if(n===R.page && R.mode==='horizontal') { flashReveal(); return; }
  R.page=n;
  if(R.mode==='horizontal'){ renderPages(); }
  else{
    const el=track.querySelector('.page[data-p="'+n+'"]');
    if(el)el.scrollIntoView({behavior:'smooth',block:'start'});
  }
  wake();
}
function flashReveal(){
  const cur=document.getElementById('curpage');
  if(!cur)return;
  cur.classList.remove('reveal');void cur.offsetWidth;cur.classList.add('reveal');
}
function openReader(id){
  const b=books[id];R.book=b;R.total=Math.min(b.pages,24);
  R.page=b.prog>0?Math.max(1,Math.round(b.prog*R.total)):1;
  document.getElementById('rtitle').textContent=b.t;
  document.getElementById('rauthor').textContent=b.a;
  buildTicks(R.total);
  R.mode='horizontal';
  [...document.getElementById('modetoggle').children].forEach(c=>c.classList.toggle('on',c.dataset.mode==='horizontal'));
  renderPages();
  reader.classList.add('open');reader.setAttribute('aria-hidden','false');
  document.body.style.overflow='hidden';
  showHint();wake();
}
function closeReader(){
  reader.classList.add('closing');
  setTimeout(()=>{reader.classList.remove('open','closing');reader.setAttribute('aria-hidden','true');},320);
}
document.getElementById('rback').addEventListener('click',closeReader);
document.getElementById('zoneL').addEventListener('click',()=>goPage(R.page-1));
document.getElementById('zoneR').addEventListener('click',()=>goPage(R.page+1));
document.getElementById('modetoggle').addEventListener('click',e=>{
  const btn=e.target.closest('button');if(!btn)return;
  R.mode=btn.dataset.mode;
  [...e.currentTarget.children].forEach(c=>c.classList.toggle('on',c===btn));
  renderPages();
  if(R.mode==='vertical'){setTimeout(()=>{const el=track.querySelector('.page[data-p="'+R.page+'"]');if(el)el.scrollIntoView({block:'start'});},40);}
  wake();
});
// scrub bar
const railtrack=document.getElementById('railtrack');
function scrubTo(clientX){
  const r=railtrack.getBoundingClientRect();
  const pct=Math.max(0,Math.min(1,(clientX-r.left)/r.width));
  goPage(Math.round(pct*(R.total-1))+1);
}
let scrubbing=false;
railtrack.addEventListener('pointerdown',e=>{scrubbing=true;railtrack.setPointerCapture(e.pointerId);scrubTo(e.clientX);});
railtrack.addEventListener('pointermove',e=>{if(scrubbing)scrubTo(e.clientX);});
railtrack.addEventListener('pointerup',()=>scrubbing=false);
document.getElementById('fsbtn').addEventListener('click',()=>{
  if(!document.fullscreenElement)document.documentElement.requestFullscreen&&document.documentElement.requestFullscreen();
  else document.exitFullscreen&&document.exitFullscreen();
});
// keyboard
document.addEventListener('keydown',e=>{
  if(!reader.classList.contains('open'))return;
  if(e.key==='ArrowRight'||e.key==='ArrowDown'){goPage(R.page+1);e.preventDefault();}
  else if(e.key==='ArrowLeft'||e.key==='ArrowUp'){goPage(R.page-1);e.preventDefault();}
  else if(e.key==='Escape')closeReader();
});

/* auto-hide chrome */
let idleT=null;
function wake(){reader.classList.remove('idle');clearTimeout(idleT);idleT=setTimeout(()=>{if(reader.classList.contains('open'))reader.classList.add('idle');},2600);}
reader.addEventListener('pointermove',wake);
reader.addEventListener('click',wake);
let hintT=null;
function showHint(){const h=document.getElementById('hint');h.style.opacity='1';clearTimeout(hintT);hintT=setTimeout(()=>{h.style.opacity='0';},3400);}

render();
