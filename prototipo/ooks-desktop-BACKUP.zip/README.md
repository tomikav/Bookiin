# Ooks

Lector de libros y manga de escritorio. Interfaz oscura ("Medianoche"), lectura
horizontal (PC) o vertical (webtoon) y animacion de revelado progresivo para manga.

Stack: **Tauri v2 + Rust** (ventana nativa) con frontend **Vite (vanilla JS)**.

> Estado actual: UI portada + biblioteca y lector con datos de ejemplo.
> Todavia no carga archivos reales (ese es el siguiente paso: PDF + carpetas de imagenes).

## Requisitos (Windows, una sola vez)

1. **Microsoft C++ Build Tools** -> instalar y marcar *"Desktop development with C++"*
   https://visualstudio.microsoft.com/visual-cpp-build-tools/
2. **Rust** (rustup): https://rustup.rs  -> luego en la terminal:
   ```
   rustup default stable-msvc
   ```
3. **Node.js LTS**: https://nodejs.org
4. **WebView2**: ya viene con Windows 10 (1803+) y Windows 11.

## Correr en modo desarrollo

```
npm install
npm run tauri dev
```

La primera vez Rust compila las dependencias y tarda un poco; luego es rapido.
Se abre una **ventana nativa** con la app. Al editar `src/` se recarga sola.

## Generar el instalable (.exe / .msi)

```
npm run tauri build
```

El instalable queda en `src-tauri/target/release/bundle/`.

## Estructura

```
index.html          markup de la UI
src/main.js         logica (biblioteca, lector, animaciones)
src/style.css       estilos (tema Medianoche)
src-tauri/          la app nativa (Rust)
  tauri.conf.json   config de la ventana y el bundle
  src/lib.rs        arranque de Tauri
  icons/            iconos de la app
```
